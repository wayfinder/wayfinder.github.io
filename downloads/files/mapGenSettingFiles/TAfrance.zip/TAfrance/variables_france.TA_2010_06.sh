MAPRELEASE="TA_2010_06";
# Long version of the map supplier, needed in variable file
# to override makemaps default value TeleAtlas_
#MAP_SUPPLIER="TeleAtlas_"

AREAPATH="${GENFILESPATH}/${MAPRELEASE}/areafiles"
CO_CODE="fr_"

MAPPATH="fullpath/TeleAtlas/2010_06_eu_shp/wf_midmif/FR"

# Setting ONLYONEMAP means that all items in the item midmifs files will be
# forced added to the one-and-only mcm map, overriding the other available
# methods for checking correctMap (within map gfxdata, settlementId,
# map ssi coord)
#ONLYONEMAP=""

AREALIST="fr_centralparis_municipalItems"


