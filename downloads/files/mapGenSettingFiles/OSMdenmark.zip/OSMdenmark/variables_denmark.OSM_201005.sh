MAPRELEASE="OSM_201005";
# Long version of the map supplier, needed in variable file
# to override makemaps default value TeleAtlas_
MAP_SUPPLIER="OpenStreetMap_"

AREAPATH="${GENFILESPATH}/${MAPRELEASE}/areafiles"
CO_CODE="den_"

MAPPATH="fullpath/OSM_201005/wf_midmif/DK"

# Setting ONLYONEMAP means that all items in the item midmifs files will be
# forced added to the one-and-only mcm map, overriding the other available
# methods for checking correctMap (within map gfxdata, settlementId,
# map ssi coord)
ONLYONEMAP="true"

AREALIST="den_whole_municipalItems"


