#MIDMIF="true"; # Map data is stored as mid/mif.
MAPRELEASE="OSM_201005";
# Long version of the map supplier, needed in variable file
# to override makemaps default value TeleAtlas_
MAP_SUPPLIER="OpenStreetMap_"

AREAPATH="${GENFILESPATH}/${MAPRELEASE}/areafiles"
CO_CODE="swe_"

MAPPATH="fullpath/OSM_201005/wf_midmif/SE"
#COPYRIGHT="� something"

# Setting ONLYONEMAP means that all items in the item midmifs files will be
# forced added to the one-and-only mcm map, overriding the other available
# methods for checking correctMap (within map gfxdata, map ssi coord, 
# settlementId)
ONLYONEMAP="true"

AREALIST="swe_whole_municipalItems"


